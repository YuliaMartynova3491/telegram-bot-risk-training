#!/bin/bash

# Скрипт для настройки проекта после клонирования

echo "Настройка проекта для безопасной работы..."

# Проверка наличия файла .env
if [ ! -f .env ]; then
    echo "Создание файла .env из шаблона..."
    cp .env.example .env
    echo "✅ Файл .env создан. Пожалуйста, заполните его своими значениями."
else
    echo "✅ Файл .env уже существует."
fi

# Проверка наличия файла config.py
if [ ! -f app/config.py ]; then
    echo "Создание файла config.py из шаблона..."
    cp app/config.py.template app/config.py
    echo "✅ Файл app/config.py создан."
else
    echo "✅ Файл app/config.py уже существует."
fi

# Обновление .gitignore для защиты конфиденциальных файлов
if ! grep -q "app/config.py" .gitignore; then
    echo "Обновление .gitignore для защиты config.py..."
    echo "app/config.py" >> .gitignore
    echo "✅ Файл .gitignore обновлен."
else
    echo "✅ Файл app/config.py уже в .gitignore."
fi

if ! grep -q ".env" .gitignore; then
    echo "Обновление .gitignore для защиты .env..."
    echo ".env" >> .gitignore
    echo "✅ Файл .gitignore обновлен."
else
    echo "✅ Файл .env уже в .gitignore."
fi

echo "
=========================================
🔐 ВАЖНОЕ НАПОМИНАНИЕ ПО БЕЗОПАСНОСТИ 🔐
=========================================

1. Отредактируйте файл .env и добавьте настоящий токен вашего Telegram бота
2. НИКОГДА не коммитьте файлы .env и app/config.py в репозиторий
3. Перед каждым коммитом проверяйте изменения командой: git diff --staged

Спасибо за соблюдение правил безопасности!
"

# Создание виртуального окружения, если его нет
if [ ! -d "venv" ]; then
    echo "Создание виртуального окружения..."
    python3 -m venv venv
    echo "✅ Виртуальное окружение создано."
else
    echo "✅ Виртуальное окружение уже существует."
fi

echo "
Для активации виртуального окружения и установки зависимостей выполните:

На Linux/macOS:
  source venv/bin/activate
  pip install -r requirements.txt

На Windows:
  venv\\Scripts\\activate
  pip install -r requirements.txt
"

echo "Настройка завершена! 🚀"